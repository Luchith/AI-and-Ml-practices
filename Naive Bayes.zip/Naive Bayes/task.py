# ================================
# STEP 1: IMPORT LIBRARIES
# ================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# NLP (only stopwords needed)
import nltk
nltk.download('stopwords')

from nltk.corpus import stopwords

# ML
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score, confusion_matrix, ConfusionMatrixDisplay


# ================================
# STEP 2: LOAD DATASET
# ================================
df = pd.read_csv('spam.csv', encoding='latin')

# Remove non-ASCII characters
df['v2'] = df['v2'].replace({r'[^\x00-\x7F]+': ''}, regex=True)

# Drop unnecessary columns
df.drop(columns=['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], inplace=True)

# Rename columns
df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)


# ================================
# STEP 3: LABEL ENCODING
# ================================
encoder = LabelEncoder()
df['target'] = encoder.fit_transform(df['target'])

print(df.head())


# ================================
# STEP 4: REMOVE DUPLICATES
# ================================
print("Duplicates before:", df.duplicated().sum())
df = df.drop_duplicates(keep='first')
print("Duplicates after:", df.duplicated().sum())


# ================================
# STEP 5: EDA FEATURES
# ================================
df['num_characters'] = df['text'].apply(len)
df['num_words'] = df['text'].str.count(' ')

# ✅ SAFE sentence count (NO NLTK punkt required)
df['num_sentences'] = df['text'].apply(
    lambda x: x.count('.') + x.count('!') + x.count('?')
)

# Spam vs Ham pie chart
plt.figure(figsize=(6, 6))
plt.pie(
    df['target'].value_counts(),
    labels=['ham', 'spam'],
    autopct='%0.2f',
    explode=[0, 0.2],
    shadow=True
)
plt.title("Spam vs Ham Distribution")
plt.show()


# ================================
# STEP 6: TEXT PREPROCESSING
# ================================
# Lowercase
df['transformed_text'] = df['text'].str.lower()

# Remove punctuation & numbers
df['transformed_text'] = df['transformed_text'].str.replace(
    r'[^a-z\s]', '', regex=True
)

# Remove stopwords
stop_words = stopwords.words('english')
df['transformed_text'] = df['transformed_text'].apply(
    lambda x: ' '.join(word for word in x.split() if word not in stop_words)
)


# ================================
# STEP 7: FEATURE EXTRACTION (TF-IDF)
# ================================
tfidf = TfidfVectorizer(max_features=3000)
X = tfidf.fit_transform(df['transformed_text'])
y = df['target'].values


# ================================
# STEP 8: TRAIN-TEST SPLIT
# ================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=2
)


# ================================
# STEP 9: TRAIN MODEL
# ================================
mnb = MultinomialNB()
mnb.fit(X_train, y_train)


# ================================
# STEP 10: EVALUATION
# ================================
y_pred = mnb.predict(X_test)

print("Accuracy Score:", accuracy_score(y_test, y_pred))
print("Precision Score:", precision_score(y_test, y_pred))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()
plt.show()
